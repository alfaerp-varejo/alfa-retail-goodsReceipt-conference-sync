export interface Sync {
    isSynced?: boolean,
    lastSyncStatus_code?: string,
    lastSyncDate?: Date,
    lastSyncMessage?: string
}