import { Cron, CronExpression } from "@nestjs/schedule";

export class Runner {
    public maxRunners = 1;
    private _runnersCount = 0;

    @Cron(CronExpression.EVERY_30_SECONDS)
    async run() {
        if (this._runnersCount < this.maxRunners) {
            this._runnersCount++;

            try {
                await this.proccess();
            } finally {
                this._runnersCount--;
            }
        }
    }

    // eslint-disable-next-line @typescript-eslint/no-empty-function
    async proccess() {

    }
}