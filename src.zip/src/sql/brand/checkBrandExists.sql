SELECT
    COUNT("Code") AS "contador"
FROM
    "{0}"."@GCV_BRANDS"
WHERE
    "Code" = '{1}'