SELECT
    COUNT("Code") AS "contador"
FROM
    "{0}"."@GCV_COLLECTIONS"
WHERE
    "Code" = '{1}'