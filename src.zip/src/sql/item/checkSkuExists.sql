SELECT
    COUNT("ItemCode") AS "contador"
FROM
    "{0}"."OITM"
WHERE
    "ItemCode" = '{1}'