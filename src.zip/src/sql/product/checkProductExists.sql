SELECT
    COUNT("Code") AS "contador"
FROM
    "{0}"."@GCV_PRODUCTS"
WHERE
    "Code" = '{1}'