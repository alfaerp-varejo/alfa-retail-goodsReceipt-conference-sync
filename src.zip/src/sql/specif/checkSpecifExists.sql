SELECT
    COUNT("Code") AS "contador"
FROM
    "{0}"."@GCV_SPECIF"
WHERE
    "Code" = '{1}'